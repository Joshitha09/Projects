package Onlinequiz;

public class loadQuestionsFromFile {

}
